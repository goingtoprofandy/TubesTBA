<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Transaksi extends Model
{
    use Notifiable;

    protected $table = "t_transaksi";

    protected $fillable = [
        'id_pesanan', 
        'metode_pembayaran', 
        'status'
    ];
}
