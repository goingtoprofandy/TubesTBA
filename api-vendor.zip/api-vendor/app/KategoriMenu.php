<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class KategoriMenu extends Model
{
    use Notifiable;

    protected $table = "t_menu_kategori";

    protected $fillable = [
        'id_menu',
        'id_kategori'
    ];
}
