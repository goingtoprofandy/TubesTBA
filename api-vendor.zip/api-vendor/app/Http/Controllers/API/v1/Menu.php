<?php

namespace App\Http\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

use App\Transformers\MenuTransformer as MenuTF;
use App\Transformers\VendorTransformer as VendorTF;

class Menu extends Controller
{
    public function collectionFilterByMerchant($merchant_id) {
        // Ambil semua data menu pada merchant dan urutkan berdasarkan merchant id
        $vendor = new VendorTF();
        if (!isset(Auth::user()->id)) {
            return $vendor->error([
                "status"    => "error",
                "message"   => "User belum ter authentikasi",
                "data"      => null
            ]);
        }

        $menu = new MenuTF();
        $getMenu = $menu->getByVendor([
            "merchant_id"   => $merchant_id
        ]);

        return $menu->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil menu",
            "data"      => $getMenu
        ]);
    }


    public function createMenu(Request $request,$merchant_id) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            // "id_vendor"         => 'required',
            "harga"             => 'required',
            "status"            => 'required',
            "name"              => 'required',
            "deskripsi"         => 'required'
        ]);


        $Menu = new MenuTF();

        if (!isset($merchant_id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

                // Jika berhasil membuat menu
                return $Menu->success([
                    "status"    => "success",
                    "message"   => "Berhasil membuat Menu",
                    "data"      => $Menu->create([
                                    "id_vendor"         => $merchant_id,
                                    "harga"             => $request->harga,
                                    "status"            => $request->status,
                                    "nama"              => $request->name,
                                    "deskripsi"         => $request->deskripsi,
                                    "created_at"        => date('Y-m-d H:i:s') ])
                ]);
    }

    public function updateMenu(Request $request,$merchant_id, $menu_id) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            // "id_vendor"         => 'required',
            "harga"             => 'required',
            "status"            => 'required',
            "name"              => 'required',
            "deskripsi"         => 'required'
        ]);


        $Menu = new MenuTF();

        if (!isset($merchant_id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

                // Jika berhasil update menu
                return $Menu->success([
                    "status"    => "success",
                    "message"   => "Berhasil mengupdate Menu",
                                    "data"      => $Menu->update([
                                        "id"                => $menu_id,
                                        "id_vendor"         => $merchant_id,
                                     ],[
                                    "harga"             => $request->harga,
                                    "status"            => $request->status,
                                    "nama"              => $request->name,
                                    "deskripsi"         => $request->deskripsi,
                                    "created_at"        => date('Y-m-d H:i:s') ])
                ]);
    }

    public function getAllMenu($merchant_id)
    {
        $Menu = new MenuTF();

        if (!isset($merchant_id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Menu->success([
            "status"    => "success",
            "message"   => "Berhasil mengupdate Menu",
            "data"      => $Menu->getMenu([
                "id_vendor" => $merchant_id,
                ])
        ]);
    }

    public function getByMenu($merchant_id, $menu_id)
    {
        $Menu = new MenuTF();

        if (!isset($merchant_id) || !isset($menu_id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Menu->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Menu->success([
            "status"    => "success",
            "message"   => "Berhasil mengupdate Menu",
            "data"      => $Menu->getMenu([
                "id_vendor" => $merchant_id,
                "id"=> $menu_id
                ])
        ]);
    }

}
