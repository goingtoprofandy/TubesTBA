<?php

namespace App\Http\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Hash;

use App\Transformers\TransaksiTransformer as TransaksiTF;


class Transaksi extends Controller
{
    public function getAllTransaksi($merchant_id)
    {
        $Transaksi = new TransaksiTF();

        if (!isset($merchant_id)) {
            return $Transaksi->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Transaksi->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Transaksi->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil pesanan",
            "data"      => $Transaksi->getAllTransaksi([
                "merchant_id" => $merchant_id
                ])
        ]);
    }

    public function getAllTransaksiOmset($merchant_id)
    {
        $Transaksi = new TransaksiTF();

        if (!isset($merchant_id)) {
            return $Transaksi->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Transaksi->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Transaksi->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil pesanan",
            "data"      => $Transaksi->getAllTransaksiOmset([
                "merchant_id" => $merchant_id
                ])
        ]);
    }
}
