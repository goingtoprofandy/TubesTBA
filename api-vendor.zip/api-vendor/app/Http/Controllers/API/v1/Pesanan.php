<?php

namespace App\Http\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Hash;

use App\Transformers\KonsumenTransformer as KonsumenTF;
use App\Transformers\PesananTransformer as PesananTF;

class Pesanan extends Controller
{
    public function getAllPesanan($merchant_id)
    {
        $Pesanan = new PesananTF();

        if (!isset($merchant_id)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Pesanan->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil pesanan",
            "data"      => $Pesanan->getAllPesanan([
                "merchant_id" => $merchant_id
                ])
        ]);
    }

    public function getPesananByStatus($merchant_id, $status)
    {
        $Pesanan = new PesananTF();

        if (!isset($merchant_id) || !isset($status)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Pesanan->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil pesanan",
            "data"      => $Pesanan->getPesananByStatus([
                "merchant_id" => $merchant_id,
                "status" => $status
                ])
        ]);
    }

    public function getPesanan($merchant_id, $id_pesanan)
    {
        $Pesanan = new PesananTF();

        if (!isset($merchant_id) || !isset($id_pesanan)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Pesanan->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        return $Pesanan->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil pesanan",
            "data"      => $Pesanan->getPesanan([
                "merchant_id" => $merchant_id,
                "id_pesanan"=>$id_pesanan
                ])
        ]);
    }
}
