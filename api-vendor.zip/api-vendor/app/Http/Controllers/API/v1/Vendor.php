<?php

namespace App\Http\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

use App\Transformers\KonsumenTransformer as KonsumenTF;
use App\Transformers\VendorTransformer as VendorTF;

class Vendor extends Controller
{
    public function collection(Request $request) {
        // Cek dan ambil data konsumen dengan menggunakan id
        $konsumen = new KonsumenTF();
        if (!isset(Auth::user()->id)) {
            return $konsumen->error([
                "status"    => "error",
                "message"   => "User belum ter authentikasi",
                "data"      => null
            ]);
        }

        $vendor = new VendorTF();
        $dataVendor = $vendor->getAll();
        return $vendor->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil vendor",
            "data"      => $dataVendor
        ]);
    }

    public function collectionFilterByCategory($category_id) {
        // Cek dan ambil data konsumen dengan menggunakan id
        $konsumen = new KonsumenTF();
        if (!isset(Auth::user()->id)) {
            return $konsumen->error([
                "status"    => "error",
                "message"   => "User belum ter authentikasi",
                "data"      => null
            ]);
        }

        if (!isset($category_id)) {
            return $konsumen->error([
                "status"    => "error",
                "message"   => "Kategori id tidak ada",
                "data"      => null
            ]);
        }

        // Ambil semua data merchant dan filter berdasarkan kategori id
        $vendor = new VendorTF();
        $dataVendor = $vendor->getByCategory([
            "id_kategori"   => $category_id
        ]);

        return $vendor->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil vendor",
            "data"      => $dataVendor
        ]);
    }

    public function collectionFilterByCategoryAndBudget($category_id, $budget) {
        // Cek dan ambil data konsumen dengan menggunakan id
        $konsumen = new KonsumenTF();
        if (!isset(Auth::user()->id)) {
            return $konsumen->error([
                "status"    => "error",
                "message"   => "User belum ter authentikasi",
                "data"      => null
            ]);
        }

        // Cek id Kategori
        if (!isset($category_id) || !isset($budget)) {
            return $konsumen->error([
                "status"    => "error",
                "message"   => "Kategori id atau budget tidak ada",
                "data"      => null
            ]);
        }

        // Ambil semua data merchant dan filter berdasarkan kategori id
        $vendor = new VendorTF();
        $dataVendor = $vendor->getByCategoryAndBudget([
            "id_kategori"   => $category_id,
            "budget"        => $budget
        ]);

        return $vendor->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil vendor",
            "data"      => $dataVendor
        ]);
    }

    public function updateVendor(Request $request,$merchant_id) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            // "id_vendor"         => 'required',
            "name"             => 'required',
            "alamat"            => 'required',
            "status"              => 'required',
            "foto_tempat"         => 'required',
            "foto_profil"         => 'required'

        ]);


        $Vendor = new VendorTF();

        if (!isset($merchant_id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

                // Jika berhasil update menu
                return $Vendor->success([
                    "status"    => "success",
                    "message"   => "Berhasil mengupdate Vendor",
                                    "data"      => $Vendor->update([
                                        "id"         => $merchant_id,
                                     ],[
                                    "nama"                => $request->name,
                                    "alamat"              => $request->alamat,
                                    "foto_tempat"         => $request->foto_tempat,
                                    "foto_profil"         => $request->foto_profil,
                                    "updated_at"          => date('Y-m-d H:i:s')
                                     ])
                ]);
    }

    public function updateTimeClose(Request $request,$merchant_id) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            // "id_vendor"         => 'required',
            "waktu_tutup"             => 'required'
        ]);


        $Vendor = new VendorTF();

        if (!isset($merchant_id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

                // Jika berhasil update menu
                return $Vendor->success([
                    "status"    => "success",
                    "message"   => "Berhasil mengupdate Vendor",
                                    "data"      => $Vendor->update([
                                        "id"         => $merchant_id,
                                     ],[
                                    "waktu_tutup"                => $request->waktu_tutup,
                                    "updated_at"          => date('Y-m-d H:i:s')
                                     ])
                ]);
    }

    public function updatePassword(Request $request,$merchant_id) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            // "id_vendor"         => 'required',
            "password_lama"             => 'required',
            "password_baru"             => 'required',
            "re_password"               => 'required'

        ]);


        $Vendor = new VendorTF();

        if (!isset($merchant_id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        if (!isset(Auth::user()->id)) {
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Email atau uid tidak tersedia",
                "data"      => null
            ]);
        }

        $checkPassword = $Vendor->getOnce([
            "id"       => $merchant_id,
            "password" => $request->password_lama
        ]);
        if ($checkPassword->password != $request->password_lama) {
            if ($request->password_baru != $request->re_password) {
                return $Vendor->error([
                    "status"    => "error",
                    "message"   => "Password salah",
                    "data"      => null
                ]);
            }
        }

                // Jika berhasil update menu
                return $Vendor->success([
                    "status"    => "success",
                    "message"   => "Berhasil mengupdate password Vendor",
                                    "data"      => $Vendor->update([
                                        "id"         => $merchant_id,
                                     ],[
                                    "password"                => $request->password_baru,
                                    "updated_at"          => date('Y-m-d H:i:s')
                                     ])
                ]);
    }

    public function vendorSaldo($merchant_id) {
        // Cek dan ambil data konsumen dengan menggunakan id
        $vendor = new VendorTF();
        if (!isset(Auth::user()->id)) {
            return $vendor->error([
                "status"    => "error",
                "message"   => "User belum ter authentikasi",
                "data"      => null
            ]);
        }

        if (!isset($merchant_id)) {
            return $vendor->error([
                "status"    => "error",
                "message"   => "Vendor tidak tersedia",
                "data"      => null
            ]);
        }

        $dataVendor = $vendor->getOnce(['id'=>$merchant_id]);
        return $vendor->success([
            "status"    => "success",
            "message"   => "Berhasil mengambil vendor",
            "data"      => ['saldo'=>$dataVendor['saldo']]
        ]);
    }

}
