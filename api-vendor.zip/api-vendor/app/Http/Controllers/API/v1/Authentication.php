<?php

namespace App\Http\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Hash;

use App\Transformers\VendorTransformer as VendorTF;

class Authentication extends Controller
{
    public function login(Request $request) {
        // Cek apakah email dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            "uid"       => 'required',
            "username"     => 'required',
            "password"     => 'required'

        ]);

        // Cek apakah email dan uid berada di database atau tidak
        $vendor = new VendorTF();
        $userAuth = $vendor->getOnce([
            "username" => $request->username,
            "uid"   => $request->uid,
            "password"   => $request->password

        ]);

        // Lakukan authentikasi by id
        if ($userAuth != null) {
            if (!Auth::loginUsingId($userAuth->id, TRUE)) {
                // Jika gagal melakukan authentikasi
                return $vendor->error([
                    "status"    => "error",
                    "message"   => "Gagal membuat authentikasi",
                    "data"      => null
                ]);
            }

            // Jika berhasil membuat authentikasi
            return $vendor->success([
                "status"    => "success",
                "message"   => "Berhasil membuat authentikasi",
                "data"      => $userAuth
            ]);
        }

        // Jika uid dan email tidak tersedia
        return $vendor->error([
            "status"    => "error",
            "message"   => "Email atau uid tidak tersedia",
            "data"      => null
        ]);
    }

    public function registration(Request $request) {
        // Cek apakah email, name, face, balance, point dan uid tersedia atau tidak pada variable request
        $this->validate($request, [
            "uid"       => 'required',
            "username"      => 'required',
            "password"     => 'required',
            "name"     => 'required',
            "status"     => 'required',
            // "waktu_tutup"     => 'required',
            "alamat"     => 'required'
        ]);


        $Vendor = new VendorTF();
        $userAuth = $Vendor->getOnce([
            "username" => $request->username,
            "password" => $request->password,
            "uid"   => $request->uid
        ]);

        // Jika belum ada maka buat Vendor baru
        if ($userAuth == null) {
            $userAuth = $Vendor->create([
                "uid"           => $request->uid,
                "username"      => $request->username,
                "password"      => $request->password,
                "nama"          => $request->name,
                "alamat"        => $request->alamat,
                "status"        => $request->status,
                // "waktu_tutup"   => $request->waktu_tutup,
                "api_token"     => Hash::make(date('Y-m-d H:i:s')),
                "created_at"    => date('Y-m-d H:i:s')
            ]);
            if ($userAuth) {
                $userAuth = $Vendor->getOnce([
                    "username" => $request->username,
                    "password" => $request->password,
                    "uid"   => $request->uid
                ]);

                // Jika berhasil membuat authentikasi
                return $Vendor->success([
                    "status"    => "success",
                    "message"   => "Berhasil membuat vendor",
                    "data"      => $userAuth
                ]);
            }

            // Jika gagal membuat Vendor
            return $Vendor->error([
                "status"    => "error",
                "message"   => "Gagal membuat vendor",
                "data"      => null
            ]);
        }

        // Jika uid dan email tersedia
        return $Vendor->error([
            "status"    => "error",
            "message"   => "vendor sudah ada sebelumnya",
            "data"      => null
        ]);
    }
}
