<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Menu extends Model
{
    use Notifiable;

    protected $table = "t_menu";

    protected $fillable = [
        'id_vendor', 
        'harga', 
        'nama',
        'deskripsi'
    ];
}
