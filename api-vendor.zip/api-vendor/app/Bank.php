<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Bank extends Model
{
    use Notifiable;

    protected $table = "m_bank";

    protected $fillable = [
        'no_rekening', 
        'nama_pemilik', 
        'tata_cara'
    ];
}
