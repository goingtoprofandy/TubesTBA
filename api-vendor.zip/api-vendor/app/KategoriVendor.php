<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class KategoriVendor extends Model
{
    use Notifiable;

    protected $table = "t_vendor_kategori";

    protected $fillable = [
        'id_vendor',
        'id_kategori'
    ];
}
