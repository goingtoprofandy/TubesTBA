<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Konsumen extends Model
{
    use Notifiable;

    protected $table = "t_konsumen";

    protected $fillable = [
        'uid', 
        'nama', 
        'email', 
        'foto_profil',
        'saldo',
        'point',
        "api_token"
    ];
}