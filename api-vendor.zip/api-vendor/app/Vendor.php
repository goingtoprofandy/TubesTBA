<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Vendor extends Authenticatable
{
    use Notifiable;

    protected $table = "t_vendor";

    protected $fillable = [
        'uid', 
        'nama', 
        'username', 
        'password', 
        'alamat',
        "api_token"
    ];
}
