<?php

namespace App\Transformers;

use App\Pesanan;
use App\Transaksi;
use App\PesananMenu;
use App\Menu;
use App\Konsumen;
use Auth;
use Illuminate\Support\Facades\DB;

class PesananTransformer {

    private $pesanan, $menu, $transaksi, $pesananMenu, $konsumen;
    public function __construct() {
        $this->pesanan  = new Pesanan();
        $this->menu     = new Menu();
        $this->transaksi = new Transaksi();
        $this->pesananMenu = new PesananMenu();
        $this->konsumen = new Konsumen();
    }

    public function create($newPesanan=[]) {
        if (count($newPesanan) > 0) {
            $this->pesanan->create($newPesanan);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedPesanan=[]) {
        if (count($updatedPesanan) > 0) {
            $this->pesanan->where($where)->update($updatedPesanan);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->pesanan->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->pesanan->where($where)->first();
        }
        return null;
    }

    public function createPesanan($orders, $date_ordered, $method_transaction) {
        // Konsumen
        $konsumen = $this->konsumen->where("id", Auth::user()->id)->first();
        // Total Harga
        $total_harga = 0;
        // Temp Menus
        $tempMenus = [];
        foreach ($orders as $order) {
            $menus = $order->menus;
            foreach ($menus as $menu) {
                $currentMenu = $this->menu->where('id', $menu->id_menu)->first();
                $total_harga += $currentMenu->harga;
                $tempMenus[] = (object)[
                    "id"        => $menu->id_menu,
                    "jumlah"    => $menu->qty
                ];
            }
        }

        $pesanan = $this->pesanan->create([
            "id_konsumen"           => Auth::user()->id,
            "total_harga"           => $total_harga,
            "tanggal_pemesanan"     => $date_ordered
        ]);

        $transaksi = $this->transaksi->create([
            "id_pesanan"            => $pesanan->id,
            "metode_pembayaran"     => $method_transaction,
            "status"                => ($konsumen->point >= $total_harga) ? 1:0
        ]);

        $tempPesananMenu = [];
        foreach ($tempMenus as $menu) {
            $tempPesananMenu[] = $this->menu->create([
                "id_pesanan"    => $pesanan->id,
                "id_menu"       => $menu->id,
                "jumlah"        => $menu->jumlah,
                "status"        => 0
            ]);
        }

        return [
            "orders"        => $pesanan,
            "transaction"   => $transaksi,
            "orderMenu"     => $tempPesananMenu
        ];
    }

    public function updatePesanan($consumer_id, $merchant_id, $order_id) {
        $pesananMenu = $this->pesananMenu->where("id_pesanan", $order_id)->get();
        $statusDone = 0;
        $tempPesananMenu = [];
        foreach ($pesananMenu as $itemPesanMenu) {
            $this->pesananMenu->where("id_pesanan", $itemPesanMenu->id)->update([
                "status" => ($itemPesanMenu->status + 1)
            ]);
            if ($itemPesanMenu->status == 3) {
                $statusDone = 1;
            }
            $tempPesananMenu[] = $this->menu->create([
                "id_pesanan"    => $itemPesanMenu->id_pesanan,
                "id_menu"       => $itemPesanMenu->id_menu,
                "jumlah"        => $itemPesanMenu->jumlah,
                "status"        => ($itemPesanMenu->status + 1)
            ]);
        }

        if ($statusDone == 1) {
            $updatePesanan = $this->pesanan->where([
                ["id", "=", $order_id]
            ])->update([
                "tanggal_penerimaan"   => strtotime(date('Y-m-d H:i:s'))
            ]);
        }

        $pesanan = $this->pesanan->where([
            ["id", "=", $order_id],
            ["id_konsumen", "=", $merchant_id]
        ])->first();

        $transaksi = $this->transaksi->where("id_pesanan", $order_id)->first();

        return [
            "orders"        => $pesanan,
            "transaction"   => $transaksi,
            "orderMenu"     => $tempPesananMenu
        ];
    }

    public function getAllPesanan($where=[]) {
        if (count($where) > 0) {
            $pesanan = DB::table('t_vendor')
            ->where('t_vendor.id', $where["merchant_id"])
            ->join('t_menu', 't_vendor.id', '=', 't_menu.id_vendor')
            ->join('t_pesan_menu', 't_menu.id', '=', 't_pesan_menu.id_menu')
            ->join('t_pesanan', 't_pesanan.id', '=', 't_pesan_menu.id_pesanan')
            ->join('t_transaksi', 't_pesanan.id', '=', 't_transaksi.id_pesanan')
            ->join('t_konsumen', 't_konsumen.id', '=', 't_pesanan.id_konsumen')
            ->select('t_vendor.id', 't_pesanan.id AS id_pesanan','t_vendor.nama AS nama_vendor', 't_vendor.alamat','t_menu.nama AS nama_menu','t_menu.harga', 't_menu.deskripsi', 't_menu.status AS status_menu', 't_pesan_menu.jumlah', 't_pesan_menu.status AS status_pesan_menu', 't_pesanan.id_konsumen'
            ,'t_transaksi.id AS id_transaksi', 't_transaksi.metode_pembayaran', 't_transaksi.status AS status_transaksi', 't_konsumen.nama AS nama_konsumen', 't_konsumen.email', 't_konsumen.foto_profil')
            ->get();

            if (count($pesanan) > 0) {
                // $getPesananMenu   = $this->pesananMenu->where("id_vendor", $where["merchant_id"])->first();
                return [

                    "id"                        => $pesanan[0]->id,
                    "id_pesanan"                => $pesanan[0]->id_pesanan,
                    "nama_vendor"               => $pesanan[0]->nama_vendor,
                    "alamat"                    => $pesanan[0]->alamat,
                    "nama_menu"                 => $pesanan[0]->nama_menu,
                    "deskripsi"                 => $pesanan[0]->deskripsi,
                    "status_menu"               => $pesanan[0]->status_menu,
                    "jumlah"                    => $pesanan[0]->jumlah,
                    "status_pesan_menu"         => $pesanan[0]->status_pesan_menu,
                    "id_konsumen"               => $pesanan[0]->id_konsumen,
                    "id_transaksi"              => $pesanan[0]->id_transaksi,
                    "metode_pembayaran"         => $pesanan[0]->metode_pembayaran,
                    "status_transaksi"          => $pesanan[0]->status_transaksi,
                    "nama_konsumen"             => $pesanan[0]->nama_konsumen,
                    "email"                     => $pesanan[0]->email,
                    "foto_profil"               => $pesanan[0]->foto_profil


                ];
            }
            return [];
        }
        return null;
    }

    public function getPesananByStatus($where=[]) {
        if (count($where) > 0) {
            $pesanan = DB::table('t_vendor')
            ->where('t_vendor.id', $where["merchant_id"])
            ->where('t_pesan_menu.status', $where["status"])
            ->join('t_menu', 't_vendor.id', '=', 't_menu.id_vendor')
            ->join('t_pesan_menu', 't_menu.id', '=', 't_pesan_menu.id_menu')
            ->join('t_pesanan', 't_pesanan.id', '=', 't_pesan_menu.id_pesanan')
            ->join('t_transaksi', 't_pesanan.id', '=', 't_transaksi.id_pesanan')
            ->join('t_konsumen', 't_konsumen.id', '=', 't_pesanan.id_konsumen')
            ->select('t_vendor.id', 't_pesanan.id AS id_pesanan','t_vendor.nama AS nama_vendor', 't_vendor.alamat','t_menu.nama AS nama_menu','t_menu.harga', 't_menu.deskripsi', 't_menu.status AS status_menu', 't_pesan_menu.jumlah', 't_pesan_menu.status AS status_pesan_menu', 't_pesanan.id_konsumen'
            ,'t_transaksi.id AS id_transaksi', 't_transaksi.metode_pembayaran', 't_transaksi.status AS status_transaksi', 't_konsumen.nama AS nama_konsumen', 't_konsumen.email', 't_konsumen.foto_profil')
            ->get();

            if (count($pesanan) > 0) {
                // $getPesananMenu   = $this->pesananMenu->where("id_vendor", $where["merchant_id"])->first();
                return [

                    "id"                        => $pesanan[0]->id,
                    "id_pesanan"                => $pesanan[0]->id_pesanan,
                    "nama_vendor"               => $pesanan[0]->nama_vendor,
                    "alamat"                    => $pesanan[0]->alamat,
                    "nama_menu"                 => $pesanan[0]->nama_menu,
                    "deskripsi"                 => $pesanan[0]->deskripsi,
                    "status_menu"               => $pesanan[0]->status_menu,
                    "jumlah"                    => $pesanan[0]->jumlah,
                    "status_pesan_menu"         => $pesanan[0]->status_pesan_menu,
                    "id_konsumen"               => $pesanan[0]->id_konsumen,
                    "id_transaksi"              => $pesanan[0]->id_transaksi,
                    "metode_pembayaran"         => $pesanan[0]->metode_pembayaran,
                    "status_transaksi"          => $pesanan[0]->status_transaksi,
                    "nama_konsumen"             => $pesanan[0]->nama_konsumen,
                    "email"                     => $pesanan[0]->email,
                    "foto_profil"               => $pesanan[0]->foto_profil


                ];
            }
            return [];
        }
        return null;
    }

    public function getPesanan($where=[]) {
        if (count($where) > 0) {
            $pesanan = DB::table('t_vendor')
            ->where('t_vendor.id', $where["merchant_id"])
            ->where('t_pesanan.id', $where["id_pesanan"])
            ->join('t_menu', 't_vendor.id', '=', 't_menu.id_vendor')
            ->join('t_pesan_menu', 't_menu.id', '=', 't_pesan_menu.id_menu')
            ->join('t_pesanan', 't_pesanan.id', '=', 't_pesan_menu.id_pesanan')
            ->join('t_transaksi', 't_pesanan.id', '=', 't_transaksi.id_pesanan')
            ->join('t_konsumen', 't_konsumen.id', '=', 't_pesanan.id_konsumen')
            ->select('t_vendor.id', 't_pesanan.id AS id_pesanan','t_vendor.nama AS nama_vendor', 't_vendor.alamat','t_menu.nama AS nama_menu','t_menu.harga', 't_menu.deskripsi', 't_menu.status AS status_menu', 't_pesan_menu.jumlah', 't_pesan_menu.status AS status_pesan_menu', 't_pesanan.id_konsumen'
            ,'t_transaksi.id AS id_transaksi', 't_transaksi.metode_pembayaran', 't_transaksi.status AS status_transaksi', 't_konsumen.nama AS nama_konsumen', 't_konsumen.email', 't_konsumen.foto_profil')
            ->get();

            if (count($pesanan) > 0) {
                // $getPesananMenu   = $this->pesananMenu->where("id_vendor", $where["merchant_id"])->first();
                return [

                    "id"                        => $pesanan[0]->id,
                    "id_pesanan"                => $pesanan[0]->id_pesanan,
                    "nama_vendor"               => $pesanan[0]->nama_vendor,
                    "alamat"                    => $pesanan[0]->alamat,
                    "nama_menu"                 => $pesanan[0]->nama_menu,
                    "deskripsi"                 => $pesanan[0]->deskripsi,
                    "status_menu"               => $pesanan[0]->status_menu,
                    "jumlah"                    => $pesanan[0]->jumlah,
                    "status_pesan_menu"         => $pesanan[0]->status_pesan_menu,
                    "id_konsumen"               => $pesanan[0]->id_konsumen,
                    "id_transaksi"              => $pesanan[0]->id_transaksi,
                    "metode_pembayaran"         => $pesanan[0]->metode_pembayaran,
                    "status_transaksi"          => $pesanan[0]->status_transaksi,
                    "nama_konsumen"             => $pesanan[0]->nama_konsumen,
                    "email"                     => $pesanan[0]->email,
                    "foto_profil"               => $pesanan[0]->foto_profil


                ];
            }
            return [];
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}
