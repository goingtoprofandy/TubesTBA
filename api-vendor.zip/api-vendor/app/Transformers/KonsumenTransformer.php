<?php

namespace App\Transformers;

use App\Konsumen;

class KonsumenTransformer {

    private $konsumen;
    public function __construct() {
        $this->konsumen = new Konsumen();
    }

    public function create($newKonsumen=[]) {
        if (count($newKonsumen) > 0) {
            $this->konsumen->create($newKonsumen);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedKonsumen=[]) {
        if (count($updatedKonsumen) > 0) {
            $this->konsumen->where($where)->update($updatedKonsumen);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->konsumen->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->konsumen->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}