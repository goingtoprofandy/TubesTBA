<?php

namespace App\Transformers;

use App\Transaksi;
use App\Vendor;

use Illuminate\Support\Facades\DB;


class TransaksiTransformer {

    private $transaksi;
    public function __construct() {
        $this->transaksi = new Transaksi();
        $this->vendor = new Vendor();

    }

    public function create($newTransaksi=[]) {
        if (count($newTransaksi) > 0) {
            $this->transaksi->create($newTransaksi);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedTransaksi=[]) {
        if (count($updatedTransaksi) > 0) {
            $this->transaksi->where($where)->update($updatedTransaksi);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->transaksi->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->transaksi->where($where)->first();
        }
        return null;
    }

    public function getAllTransaksi($where=[]) {
        if (count($where) > 0) {
            $transaksi = DB::table('t_vendor')
            ->where('t_vendor.id', $where["merchant_id"])
            ->where('t_transaksi.status', 1)
            ->join('t_menu', 't_vendor.id', '=', 't_menu.id_vendor')
            ->join('t_pesan_menu', 't_menu.id', '=', 't_pesan_menu.id_menu')
            ->join('t_pesanan', 't_pesanan.id', '=', 't_pesan_menu.id_pesanan')
            ->join('t_transaksi', 't_pesanan.id', '=', 't_transaksi.id_pesanan')
            ->join('t_konsumen', 't_konsumen.id', '=', 't_pesanan.id_konsumen')
            ->select('t_vendor.id', 't_vendor.nama AS nama_vendor', 't_pesanan.total_harga', 't_pesanan.tanggal_pemesanan', 't_pesanan.tanggal_penerimaan', 't_transaksi.status AS status_transaksi')
            ->get();

            if (count($transaksi) > 0) {
                // $getPesananMenu   = $this->pesananMenu->where("id_vendor", $where["merchant_id"])->first();
                return [

                    "id"                        => $transaksi[0]->id,
                    "nama_vendor"               => $transaksi[0]->nama_vendor,
                    "total_harga"               => $transaksi[0]->total_harga,
                    "tanggal_pemesanan"         => $transaksi[0]->tanggal_pemesanan,
                    "tanggal_penerimaan"        => $transaksi[0]->tanggal_penerimaan,
                    "status_transaksi"          => $transaksi[0]->status_transaksi
                ];
            }
            return [];
        }
        return null;
    }

    public function getAllTransaksiOmset($where=[]) {
        if (count($where) > 0) {
            $getDataVendor = $this->vendor->where('id', $where["merchant_id"])->first();
            for ($bln = 1; $bln <= 12 ; $bln++) {
                $transaksi = DB::table('t_vendor')
                ->where('t_vendor.id', $where["merchant_id"])
                ->where('t_transaksi.status', 1)
                ->whereMonth('t_transaksi.created_at', $bln)
                ->join('t_menu', 't_vendor.id', '=', 't_menu.id_vendor')
                ->join('t_pesan_menu', 't_menu.id', '=', 't_pesan_menu.id_menu')
                ->join('t_pesanan', 't_pesanan.id', '=', 't_pesan_menu.id_pesanan')
                ->join('t_transaksi', 't_pesanan.id', '=', 't_transaksi.id_pesanan')
                ->join('t_konsumen', 't_konsumen.id', '=', 't_pesanan.id_konsumen')
                ->select(DB::raw('SUM(t_pesanan.total_harga) AS omset'))
                ->get();
                $hasil[] = $transaksi[0]->omset;
            }


            if (count($transaksi) > 0) {
                // $getPesananMenu   = $this->pesananMenu->where("id_vendor", $where["merchant_id"])->first();
                return [
                    "id" => $getDataVendor->id,
                    "nama" => $getDataVendor->nama,
                    "omset_perbulan" => $hasil
                    // "id" => $getDataVendor->id

                ];
            }
            return [];
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}
