<?php

namespace App\Transformers;

use App\Vendor;
use App\Kategori;
use App\KategoriVendor;
use App\Menu;

class VendorTransformer {

    private $vendor, $kategori, $kategoriVendor, $menu;
    public function __construct() {
        $this->vendor = new Vendor();
        $this->kategori = new Kategori();
        $this->kategoriVendor = new KategoriVendor();
        $this->menu = new Menu();
    }

    public function create($newVendor=[]) {
        if (count($newVendor) > 0) {
            $this->vendor->create($newVendor);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedVendor=[]) {
        if (count($updatedVendor) > 0) {
            $this->vendor->where($where)->update($updatedVendor);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->vendor->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->vendor->where($where)->first();
        }
        return null;
    }

    public function getAll() {
        return $this->vendor->orderBy("id", "DESC");
    }

    public function getByCategory($where=[]) {
        if (count($where) > 0) {
            $getCategoryVendor = $this->kategoriVendor->where($where)->get();
            $temp = [];
            foreach ($getCategoryVendor as $categoryVendor) {
                $vendor = $this->vendor->where("id", $categoryVendor->id_vendor)->first();
                $category = $this->kategori->where("id", $categoryVendor->id_kategori)->first();
                $temp[] = [
                    "id"                => $vendor->id,
                    "uid"               => $vendor->uid,
                    "name"              => $vendor->nama,
                    "category"          => $category->kategori,
                    "status_merchant"   => $vendor->status,
                    "closed_time"       => $vendor->waktu_tutup,
                    "photo_place"       => $vendor->foto_tempat,
                    "photo_profile"     => $vendor->foto_profil,
                    "address"           => $vendor->alamat
                ];
            }
            return $temp;
        }
        return null;
    }

    public function getByCategoryAndBudget($where=[]) {
        if (count($where) > 0) {
            $getCategoryVendor = $this->kategoriVendor->where("id_kategori", $where["id_kategori"])->get();
            $temp = [];
            foreach ($getCategoryVendor as $categoryVendor) {
                $vendor     = $this->vendor->where("id", $categoryVendor->id_vendor)->first();
                $category   = $this->kategori->where("id", $categoryVendor->id_kategori)->first();
                $checkMenu  = $this->menu->where([
                    ["id_vendor", "=", $vendor->id],
                    ["harga", "<=", $where["budget"]]
                ])->count();
                if ($checkMenu > 0) {
                    $temp[] = [
                        "id"                => $vendor->id,
                        "uid"               => $vendor->uid,
                        "name"              => $vendor->nama,
                        "category"          => $category->kategori,
                        "status_merchant"   => $vendor->status,
                        "closed_time"       => $vendor->waktu_tutup,
                        "photo_place"       => $vendor->foto_tempat,
                        "photo_profile"     => $vendor->foto_profil,
                        "address"           => $vendor->alamat
                    ];
                }
            }
            return $temp;
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}