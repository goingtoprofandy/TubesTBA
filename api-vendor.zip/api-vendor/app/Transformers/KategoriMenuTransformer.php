<?php

namespace App\Transformers;

use App\KategoriMenu;

class KategoriMenuTransformer {

    private $kategoriMenu;
    public function __construct() {
        $this->kategoriMenu = new KategoriMenu();
    }

    public function create($newKategoriMenu=[]) {
        if (count($newKategoriMenu) > 0) {
            $this->kategoriMenu->create($newKategoriMenu);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedKategoriMenu=[]) {
        if (count($updatedKategoriMenu) > 0) {
            $this->kategoriMenu->where($where)->update($updatedKategoriMenu);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->kategoriMenu->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->kategoriMenu->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}