<?php

namespace App\Transformers;

use App\Menu;
use App\Vendor;
use App\Kategori;
use App\KategoriVendor;

class MenuTransformer {

    private $menu, $vendor, $kategori, $kategoriVendor;
    public function __construct() {
        $this->menu = new Menu();
        $this->vendor = new Vendor();
        $this->kategori = new Kategori();
        $this->kategoriVendor = new KategoriVendor();
    }

    public function create($newMenu=[]) {
        if (count($newMenu) > 0) {
            $this->menu->create($newMenu);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedMenu=[]) {
        if (count($updatedMenu) > 0) {
            $this->menu->where($where)->update($updatedMenu);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->menu->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->menu->where($where)->first();
        }
        return null;
    }

    public function getByVendor($where=[]) {
        if (count($where) > 0) {
            $vendor = $this->vendor->where("id", $where["merchant_id"])->first();
            $getCategoryVendor = $this->kategoriVendor->where("id", $where["merchant_id"])->first();
            if ($getCategoryVendor != null) {
                $category = $this->kategori->where("id", $getCategoryVendor->id_kategori)->first();
                $menu   = $this->menu->where("id_vendor", $where["merchant_id"])->get();
                return [
                    "id"                => $vendor->id,
                    "uid"               => $vendor->uid,
                    "name"              => $vendor->nama,
                    "category"          => $category->kategori,
                    "status_merchant"   => $vendor->status,
                    "closed_time"       => $vendor->waktu_tutup,
                    "photo_place"       => $vendor->foto_tempat,
                    "photo_profile"     => $vendor->foto_profil,
                    "address"           => $vendor->alamat,
                    "menus"             => $menu
                ];
            }
            return [];
        }
        return null;
    }

    public function getMenu($where=[]) {
        if (count($where) > 0) {
            $menu   = $this->menu->where($where)->get();
            if ($menu != null) {
                return [
                    "menus"             => $menu
                ];
            }
            return [];
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}
