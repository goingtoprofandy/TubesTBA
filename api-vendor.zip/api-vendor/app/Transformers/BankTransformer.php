<?php

namespace App\Transformers;

use App\Bank;

class BankTransformer {

    private $bank;
    public function __construct() {
        $this->bank = new Bank();
    }

    public function create($newBank=[]) {
        if (count($newBank) > 0) {
            $this->bank->create($newBank);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedBank=[]) {
        if (count($updatedBank) > 0) {
            $this->bank->where($where)->update($updatedBank);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->bank->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->bank->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}