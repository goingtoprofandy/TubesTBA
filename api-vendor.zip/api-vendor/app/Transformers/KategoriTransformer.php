<?php

namespace App\Transformers;

use App\Kategori;

class KategoriTransformer {

    private $kategori;
    public function __construct() {
        $this->kategori = new Kategori();
    }

    public function create($newKategori=[]) {
        if (count($newKategori) > 0) {
            $this->kategori->create($newKategori);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedKategori=[]) {
        if (count($updatedKategori) > 0) {
            $this->kategori->where($where)->update($updatedKategori);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->kategori->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->kategori->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}