<?php

namespace App\Transformers;

use App\PesananMenu;

class PesananMenuTransformer {

    private $pesananMenu;
    public function __construct() {
        $this->pesananMenu = new PesananMenu();
    }

    public function create($newPesananMenu=[]) {
        if (count($newPesananMenu) > 0) {
            $this->pesananMenu->create($newPesananMenu);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedPesananMenu=[]) {
        if (count($updatedPesananMenu) > 0) {
            $this->pesananMenu->where($where)->update($updatedPesananMenu);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->pesananMenu->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->pesananMenu->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}