<?php

namespace App\Transformers;

use App\PermintaanSaldo;

class PermintaanSaldoTransformer {

    private $permintaanSaldo;
    public function __construct() {
        $this->permintaanSaldo = new Menu();
    }

    public function create($newPermintaanSaldo=[]) {
        if (count($newPermintaanSaldo) > 0) {
            $this->permintaanSaldo->create($newPermintaanSaldo);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedPermintaanSaldo=[]) {
        if (count($updatedPermintaanSaldo) > 0) {
            $this->permintaanSaldo->where($where)->update($updatedPermintaanSaldo);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->permintaanSaldo->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->permintaanSaldo->where($where)->first();
        }
        return null;
    }

    public function createBalanceRequest($newPermintaanSaldo=[]) {
        if (count($newPermintaanSaldo) > 0) {
            return $this->permintaanSaldo->create($newPermintaanSaldo);
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}