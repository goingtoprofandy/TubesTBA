<?php

namespace App\Transformers;

use App\KategoriVendor;

class KategoriVendorTransformer {

    private $kategoriVendor;
    public function __construct() {
        $this->kategoriVendor = new KategoriVendor();
    }

    public function create($newKategoriVendor=[]) {
        if (count($newKategoriVendor) > 0) {
            $this->kategoriVendor->create($newKategoriVendor);
            return true;
        }
        return false;
    }

    public function update($where=[], $updatedKategoriVendor=[]) {
        if (count($updatedKategoriVendor) > 0) {
            $this->kategoriVendor->where($where)->update($updatedKategoriVendor);
            return true;
        }
        return false;
    }

    public function delete($where=[]) {
        if (count($where) > 0) {
            $this->kategoriVendor->where($where)->delete();
            return true;
        }
        return false;
    }

    public function getOnce($where=[]) {
        if (count($where) > 0) {
            return $this->kategoriVendor->where($where)->first();
        }
        return null;
    }

    public function success($data) {
        return response()->json(
            [
                "data"  => $data
            ], 200
        );
    }

    public function error($data) {
        return response()->json(
            [
                "data"  => $data
            ], 401
        );
    }

}