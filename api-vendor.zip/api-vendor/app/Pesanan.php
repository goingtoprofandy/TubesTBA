<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Pesanan extends Model
{
    use Notifiable;

    protected $table = "t_pesanan";

    protected $fillable = [
        'id_konsumen', 
        'total_harga',
        'tanggal_pemesanan'
    ];
}