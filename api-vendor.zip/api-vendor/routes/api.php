<?php

use Illuminate\Http\Request;

$apps = [
    "api_v1" => "API\\v1\\", // For Aplication Consumer V1
];

Route::post('/auth/login', $apps["api_v1"] . 'Authentication@login');
Route::post('/auth/registration', $apps["api_v1"] . 'Authentication@registration');

//profil vendor
Route::post('/merchant/updateprofil/{merchant_id}', $apps["api_v1"] . 'Vendor@updateVendor')->middleware('auth:api');
//Ganti Waktu tutup vendor
Route::post('/merchant/updatetime/{merchant_id}', $apps["api_v1"] . 'Vendor@updateTimeClose')->middleware('auth:api');
//Ganti Password
Route::post('/merchant/updatepassword/{merchant_id}', $apps["api_v1"] . 'Vendor@updatePassword')->middleware('auth:api');
//Saldo Vendor
Route::get('/merchant/vendorSaldo/{merchant_id}', $apps["api_v1"] . 'Vendor@vendorSaldo')->middleware('auth:api');

//menu
Route::get('/menu/merchant/{merchant_id}', $apps["api_v1"] . 'Menu@collectionFilterByMerchant')->middleware('auth:api');
Route::get('/menu/getAllMenu/{merchant_id}', $apps["api_v1"] . 'Menu@getAllMenu')->middleware('auth:api');
Route::get('/menu/getMenu/{merchant_id}/{menu_id}', $apps["api_v1"] . 'Menu@getByMenu')->middleware('auth:api');
Route::post('/menu/insert/{merchant_id}', $apps["api_v1"] . 'Menu@createMenu')->middleware('auth:api');
Route::post('/menu/update/{merchant_id}/{menu_id}', $apps["api_v1"] . 'Menu@updateMenu')->middleware('auth:api');

//Pesanan
Route::get('/pesanan/getAllPesanan/{merchant_id}', $apps["api_v1"] . 'Pesanan@getAllPesanan')->middleware('auth:api');
Route::get('/pesanan/getPesananByStatus/{merchant_id}/{status}', $apps["api_v1"] . 'Pesanan@getPesananByStatus')->middleware('auth:api');
Route::get('/pesanan/getPesanan/{merchant_id}/{id_pesanan}', $apps["api_v1"] . 'Pesanan@getPesanan')->middleware('auth:api');

//Transaksi
Route::get('/transaksi/getAllTransaksi/{merchant_id}', $apps["api_v1"] . 'Transaksi@getAllTransaksi')->middleware('auth:api');
Route::get('/transaksi/getAllTransaksiOmset/{merchant_id}', $apps["api_v1"] . 'Transaksi@getAllTransaksiOmset')->middleware('auth:api');



//php -S localhost:8000 -t public


